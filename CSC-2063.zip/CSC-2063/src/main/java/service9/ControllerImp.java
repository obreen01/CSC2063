
package service9;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for controllerImp complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="controllerImp">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "controllerImp")
public class ControllerImp 
{
	//variables 
		private RoleImp role;
	//methods 
		//batch registration
		public void batchRegistration()
		{
			//steps 
			//getId
			//checkRole
			//Add into correct Array
		}
		
		//Enrolling Student on a module
		public void studentEnrolment()
		{
			//check user = ASM
			//checks student is registered 
			//returns 0 if works 
		}
		
		//Inserting a new mark
		public void setMark()
		{
			//check for ASM
			//Checks Student
			//Checks Student Matches module
			//inserts mark
			//returns 0
		}
		
		//get module details
		public void getModuleDetails()
		{
			//checks for ASM
			//checks student
			//checks student matches module 
			// returns module code, academic year and mark
		}
		
		//Assigning module to an academic staff member 
		public void staffModuleAssignment()
		{
			//checks ASM
			//new module added and assigned to the ASM 
			//returns 0 when done
		}

}
