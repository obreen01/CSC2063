
package service9;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for roleE.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="roleE">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="ACADEMIC_STAFF_MEMBER"/>
 *     &lt;enumeration value="STUDENT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "roleE")
@XmlEnum
public enum RoleE {

    ACADEMIC_STAFF_MEMBER,
    STUDENT;

    public String value() {
        return name();
    }

    public static RoleE fromValue(String v) {
        return valueOf(v);
    }

}
