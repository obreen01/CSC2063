
package service31;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for student complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="student">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "student", propOrder = {
    "id"
})
public class Student {

    protected int id;
    private ModuleCode31[] code = new ModuleCode31[20];
	private Module31[] module = new Module31[20];
    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }
//getters
    public  ModuleCode31[] getModuleCodes()
	{
		return code;
	}
			
	public Module31[] getModules()
	{
		return module;
	}
//setters
	public  void setModuleCode(ModuleCode31 moduleCode, int pos)
	{
		this.code[pos] = moduleCode;
	}
			
	public  void setModule(Module31 module, int pos)
	{
		this.module[pos] = module;
	}
}
