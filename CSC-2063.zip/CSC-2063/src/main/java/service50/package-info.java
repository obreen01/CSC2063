@javax.xml.bind.annotation.XmlSchema(namespace = "http://service50/")
package service50;
