
package service50;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for academicStaffMember complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="academicStaffMember">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "academicStaffMember", propOrder = {
    "id"
})
public class AcademicStaffMember {

    protected int id;
    protected ModuleCode[] code = new ModuleCode[2];
	protected Module[] module = new Module[2];
    /**
     * Gets the value of the id property.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }
//getters
    public  ModuleCode[] getModuleCodes()
	{
		return code;
	}
			
	public Module[] getModules()
	{
		return module;
	}
//setters
	public  void setModuleCode(ModuleCode moduleCode, int pos)
	{
		this.code[pos] = moduleCode;
	}
	
	public  void setModule(Module module, int pos)
	{
		this.module[pos] = module;
	}
}
